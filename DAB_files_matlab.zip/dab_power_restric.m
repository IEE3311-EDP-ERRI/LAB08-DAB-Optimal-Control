function [r, req]=dab_power_restric(x, fsw, Vdc1 , N, Vdc2 , L12 , h_rest, P2_ref) 
r = [];

% x(1) = D1 ;
% x(2) = D2 ;
% x(3) = d14*pi = psi_14 ;
% Vdc2; 
% P12, P13, P14, P23, P24, P34 

P12 = 0 ;
for i=0:1:h_rest  
	k = 2*i + 1;
    %k = 1 ; 
P12_k = (  (4*Vdc1*N*Vdc2/(pi*pi*pi*fsw*L12))*(1/(k*k*k))*sin(k*pi*x(1))*sin(k*pi*x(2))*sin(k*x(3))  ) ;  
P12 = P12 + P12_k ; 

end


%req(1) =  Iout - Iout_ref ;
req(1) =  P12 - P2_ref ;