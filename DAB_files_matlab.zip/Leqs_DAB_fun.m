function [L12]=Leqs_DAB_fun(xp,P12,Vdc1,Vdc2,a12) 

fsw = 50e3 ; 

xx = 1 ;
xp12 = xx*xp*1.0* 0.25 * ( pi*pi )/( ( 90*pi/180)*(pi - 90*pi/180) ) ; 
L12_1 = ( Vdc1*Vdc2*(a12)*0.5*0.5 ) / ( 2*fsw*P12*xp12 ) ;

% % x = [ x(1) , x(2) , x(3) ] = [ L1_1 , L2_1 , L3_1 ] ; 
% F = @(y) [( y(1)+ y(2) ) -L12_1;  % SOLO SE TIENE ESTA CONDICION, ENTONCES NO SE PUEDE RESOLVER L1 Y L2 PARA EL DAB
%     ((y(1)*y(2)+y(2)*y(3)+y(1)*y(3))/y(2))-L13_1; 
%     ((y(1)*y(2)+y(2)*y(3)+y(1)*y(3))/y(1))-L23_1] ; 
% 
% y0 = [50;50]*1e-6 ; 
% 
% 
% options = optimoptions('fsolve','Display','off');
% y = fsolve(F,y0,options) ; 
% 
% % fprintf('Inductancias reales en [uH]') ;
% L1 = ( y(1)*(1)^2 * 1e6  ) ; 
% L2 = ( y(2)*(1/a12)^2 * 1e6  ) ; 
% % L12 = L_1 + L_2*a12*a12  ;
% L12 = [(L1), (L2)] ; 

L12 = L12_1 ; 

